INSERT INTO sales(sale_date,city,product,amount,price)
VALUES
('2025-06-27','London','Umbrella',5,12.99),
('2025-06-28','Paris','Sunscreen',2,39.99);

SELECT * FROM sales;

INSERT INTO weather(weather_date,city,temp_c,humidity,description)
VALUES
('2025-06-27','London',18.3,80,'light rain'),
('2025-06-28','Paris',12.1,60,'clear sky');

SELECT * FROM weather;